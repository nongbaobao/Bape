package mc.bape.Gui.VapeClickGui;

public enum ClickType {
    Home
}
