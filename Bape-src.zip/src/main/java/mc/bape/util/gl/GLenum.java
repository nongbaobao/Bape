package mc.bape.util.gl;

public interface GLenum {
    public String getName();

    public int getCap();
}

